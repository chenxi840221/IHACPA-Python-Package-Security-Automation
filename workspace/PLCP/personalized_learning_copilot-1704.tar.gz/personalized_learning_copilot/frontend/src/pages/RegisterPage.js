import React from 'react';
import Register from '../components/Register';

const RegisterPage = () => {
  return (
    <div className="container mx-auto">
      <Register />
    </div>
  );
};

export default RegisterPage;